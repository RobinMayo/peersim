Project Peersim by :

Blottière-Mayo Robin  3200248
Oumeddour Pierre      3100478

Pour compiler

./Blottiere_Oumeddour-peersim/javac.sh

Pour executer l'application

./Blottiere_Oumeddour-peersim/java_ex.sh


Nous avons utilisé un script python pour lancer plusieurs exécutions d'affiler en changent la configuration à chaque exécution et faire des calcules sur les résultats obtenus. Nous l'avons laissé dans l'archive pour montrer notre méthode de travail. Dans ce script, les paramètres d'expériences sont écrits en dure.