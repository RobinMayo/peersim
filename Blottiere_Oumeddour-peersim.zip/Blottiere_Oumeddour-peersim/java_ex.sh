java -cp bin/:lib/*: peersim.Simulator bin/projetara/config_exo1_q4.txt
